package com.amdo.Dentist.repo;

import java.sql.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.amdo.entity.Appointment;

@Repository
public interface AppointmrntReposiotry  extends JpaRepository<Appointment, Integer>{
	@Query(
			  value = "SELECT count(*) FROM Appointment WHERE doctor_id = ?1 && date=?2", 
			  nativeQuery = true)	
	public int findCountOfPatient(int doctorId,Date date);
}
