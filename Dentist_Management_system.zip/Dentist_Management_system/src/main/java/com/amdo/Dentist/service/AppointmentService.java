package com.amdo.Dentist.service;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amdo.Dentist.repo.AppointmrntReposiotry;
import com.amdo.entity.Appointment;
import com.amdo.entity.Doctor;
import com.amdo.entity.Patient;

@Service
public class AppointmentService {
  @Autowired
  private AppointmrntReposiotry  appointmrntReposiotry;
  
  @Autowired
  private PatientService patientService;
  @Autowired
  private DoctorService doctorService;
  public void bookAppointment(Appointment appointment,int patientId,int doctorId) {
	  Patient patient = patientService.getById(patientId);
	  Doctor doctor = doctorService.getById(doctorId);
	  appointment.setDoctor(doctor);
	  appointment.setPatient(patient);
	  appointmrntReposiotry.save(appointment);
  }
  public int countOfPatientInDay(int doctorId,Date date) {
	  return appointmrntReposiotry.findCountOfPatient(doctorId, date);
  }
}
