package com.amdo.Dentist.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amdo.Dentist.repo.DoctorRepository;
import com.amdo.entity.Doctor;

@Service
public class DoctorService {
   @Autowired
   private DoctorRepository  doctorRepository;
   
   public Doctor save(Doctor d) {
	   return doctorRepository.save(d);
	   
   }
   
   public List<Doctor> getAll(){
	   return doctorRepository.findAll();
   }
   
   public Doctor getById(int id) {
	   return doctorRepository.findById(id).get();
   }
}
