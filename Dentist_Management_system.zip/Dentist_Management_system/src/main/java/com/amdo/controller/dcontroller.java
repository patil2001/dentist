package com.amdo.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amdo.Dentist.service.AppointmentService;
import com.amdo.Dentist.service.DoctorService;
import com.amdo.entity.Doctor;

@RestController
@RequestMapping("/doctor")
public class dcontroller {

	@Autowired
	private DoctorService doctorService;
	
	@Autowired
	private AppointmentService appointmentService;
	@PostMapping
	public Doctor save(@RequestBody Doctor doctor) {
		return doctorService.save(doctor);
	}
	
	@GetMapping("/report/{doctorId}/{date}")
	public int countOfPatient(@PathVariable("doctorId") int doctorId ,@PathVariable("date") Date date) {
		return appointmentService.countOfPatientInDay(doctorId, date);
	}
	
	@GetMapping
	public List<Doctor> getAll(){
		return doctorService.getAll();
	}
}
