package com.amdo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amdo.Dentist.service.PatientService;
import com.amdo.entity.Patient;

@RestController
@RequestMapping("/patient")
public class PatientController {
	@Autowired
  private PatientService patientService;
	
	@PostMapping
	public Patient save( @RequestBody Patient p) {
		return patientService.save(p);
	}
	
	
	@GetMapping
	public List<Patient> getAll(){
		return patientService.getAll();
	}
}
